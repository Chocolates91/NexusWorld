@echo off
cd /d "%~dp0"
start "Nexus World" "NexusWorld.exe"
